package com.aiweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class AiWebApplicationTests {

    @Test
    void contextLoads() {
    }

}
