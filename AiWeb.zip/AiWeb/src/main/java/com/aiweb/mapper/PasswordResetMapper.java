package com.aiweb.mapper;

import com.aiweb.entity.PasswordReset;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PasswordResetMapper extends BaseMapper<PasswordReset> {

}
