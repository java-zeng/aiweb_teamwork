package com.aiweb.controller;

import com.aiweb.entity.FastGptApiData;
import com.aiweb.entity.FastGptApiResponse;
import com.aiweb.entity.UserDocument;
import com.aiweb.service.FastGptService;
import com.aiweb.service.UserDocumentService;
import com.aiweb.utils.JwtUtil;
import com.aiweb.utils.FilenameEncodingUtils;
import com.aiweb.utils.EncodingTestUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import jakarta.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.util.List;

@RestController
@Slf4j
@RequestMapping("/api/v1/collections")
public class FastGptController {
    
    @Autowired
    private FastGptService fastGptService;

    @Autowired
    private JwtUtil jwtUtil;
    
    @Autowired
    private UserDocumentService userDocumentService;

    /**
     * 原始文件上传接口（需要手动指定datasetId）
     */
    @PostMapping("/create-from-file")
    public ResponseEntity<?> CreateListFormFiles(
            @RequestParam("file") MultipartFile file,
            @RequestParam("datasetId") String datasetId,
            @RequestParam(value = "parentId", required = false) String parentId,
            @RequestParam(value = "chunkSize", required = false) Integer chunkSize
    ) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body("上传文件不能为空!");
        }
        try {
            FastGptApiData fastGptApiData = new FastGptApiData(
                    datasetId,
                    "chunk",
                    parentId,
                    null,
                    null,
                    null,
                    null,
                    chunkSize != null ? "custom" : "auto",
                    null,
                    chunkSize,
                    null, null, null, null, null
            );
            FastGptApiResponse fastGptApiResponse = fastGptService.CreateListFromFiles(file, fastGptApiData);
            return ResponseEntity.ok(fastGptApiResponse);
        } catch (Exception e) {
            log.error("文件上传失败:{}", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("文件上传失败:" + e.getMessage());
        }
    }

    /**
     * 自动上传接口（自动创建用户数据集，记录文件信息）
     */
    @PostMapping("/auto-upload")
    public ResponseEntity<?> autoUpload(
            Authentication authentication,
            HttpServletRequest request,
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "parentId", required = false) String parentId,
            @RequestParam(value = "chunkSize", required = false) Integer chunkSize
    ) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body("上传文件不能为空!");
        }
        
        String username = null;
        try {
            // 获取用户名
            if (authentication != null) {
                username = authentication.getName();
            }
            if (username == null || username.isEmpty()) {
                String authHeader = request.getHeader("Authorization");
                if (authHeader != null && authHeader.startsWith("Bearer ")) {
                    String token = authHeader.substring("Bearer ".length());
                    username = jwtUtil.extractUsername(token);
                }
            }
            if (username == null || username.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("未认证，缺少有效的 Authorization Bearer token");
            }
            
            // 确保用户数据集存在
            String datasetId = fastGptService.ensureUserDataset(username);
            
            // 获取正确的文件名（解决编码问题，保持原始文件名）
            String originalFilename = FilenameEncodingUtils.getCorrectFilename(file);
            log.info("用户 {} 上传文件: {}", username, originalFilename);
            
            // 检查重复文件名
            List<UserDocument> existingDocuments = userDocumentService.getUserDocuments(username);
            List<String> existingFilenames = existingDocuments.stream()
                    .map(UserDocument::getOriginalFilename)
                    .collect(java.util.stream.Collectors.toList());
            
            // 处理重复文件名
            String finalFilename = FilenameEncodingUtils.handleDuplicateFilename(originalFilename, existingFilenames);
            if (!finalFilename.equals(originalFilename)) {
                log.info("检测到重复文件名，已处理: {} -> {}", originalFilename, finalFilename);
            }
            
            // 创建文档记录
            UserDocument userDocument = new UserDocument();
            userDocument.setUsername(username);
            userDocument.setDatasetId(datasetId);
            userDocument.setOriginalFilename(finalFilename);
            userDocument.setFileSize(file.getSize());
            userDocument.setFileType(getFileExtension(finalFilename));
            userDocument.setStatus("uploading");
            
            // 保存文档记录
            Long documentId = userDocumentService.saveUserDocument(userDocument);
            
            // 记录文件名处理过程，便于调试
            log.info("文件名处理完成 - 原始: {}, 处理后: {}, 文档ID: {}", 
                    file.getOriginalFilename(), originalFilename, documentId);
            
            // 上传到FastGPT
            FastGptApiData data = new FastGptApiData(
                    datasetId,
                    "chunk",
                    parentId,
                    null,
                    null,
                    null,
                    null,
                    chunkSize != null ? "custom" : "auto",
                    null,
                    chunkSize,
                    null, null, null, null, null
            );
            
            FastGptApiResponse resp = fastGptService.CreateListFromFiles(file, data);
            
            // 更新文档状态
            userDocument.setId(documentId);
            userDocument.setStatus("completed");
            if (resp != null && resp.getData() != null && resp.getData().getCollectionId() != null) {
                userDocument.setFastgptDocumentId(resp.getData().getCollectionId());
            }
            userDocumentService.updateById(userDocument);
            
            log.info("文件上传成功: 用户={}, 文件名={}, 文档ID={}", username, originalFilename, documentId);
            return ResponseEntity.ok(resp);
            
        } catch (Exception e) {
            log.error("自动上传失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("自动上传失败:" + e.getMessage());
        }
    }
    
    /**
     * 获取用户上传的文件列表
     */
    @GetMapping("/documents")
    public ResponseEntity<?> getUserDocuments(
            Authentication authentication,
            HttpServletRequest request
    ) {
        try {
            String username = null;
            if (authentication != null) {
                username = authentication.getName();
            }
            if (username == null || username.isEmpty()) {
                String authHeader = request.getHeader("Authorization");
                if (authHeader != null && authHeader.startsWith("Bearer ")) {
                    String token = authHeader.substring("Bearer ".length());
                    username = jwtUtil.extractUsername(token);
                }
            }
            if (username == null || username.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("未认证，缺少有效的 Authorization Bearer token");
            }
            
            List<UserDocument> documents = userDocumentService.getUserDocuments(username);
            return ResponseEntity.ok(documents);
            
        } catch (Exception e) {
            log.error("获取用户文档列表失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取文档列表失败:" + e.getMessage());
        }
    }
    
    /**
     * 删除用户文档
     */
    @DeleteMapping("/documents/{documentId}")
    public ResponseEntity<?> deleteUserDocument(
            @PathVariable Long documentId,
            Authentication authentication,
            HttpServletRequest request
    ) {
        try {
            String username = null;
            if (authentication != null) {
                username = authentication.getName();
            }
            if (username == null || username.isEmpty()) {
                String authHeader = request.getHeader("Authorization");
                if (authHeader != null && authHeader.startsWith("Bearer ")) {
                    String token = authHeader.substring("Bearer ".length());
                    username = jwtUtil.extractUsername(token);
                }
            }
            if (username == null || username.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("未认证，缺少有效的 Authorization Bearer token");
            }
            
            boolean success = userDocumentService.deleteUserDocument(documentId, username);
            if (success) {
                return ResponseEntity.ok("文档删除成功");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("文档不存在或无权限删除");
            }
            
        } catch (Exception e) {
            log.error("删除用户文档失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("删除文档失败:" + e.getMessage());
        }
    }
    
    
    /**
     * 测试文件名编码修复和重复处理
     * 仅用于调试，生产环境应移除
     */
    @PostMapping("/test-filename-encoding")
    public ResponseEntity<?> testFilenameEncoding(
            @RequestParam("file") MultipartFile file,
            Authentication authentication,
            HttpServletRequest request
    ) {
        try {
            String username = null;
            if (authentication != null) {
                username = authentication.getName();
            }
            if (username == null || username.isEmpty()) {
                String authHeader = request.getHeader("Authorization");
                if (authHeader != null && authHeader.startsWith("Bearer ")) {
                    String token = authHeader.substring("Bearer ".length());
                    username = jwtUtil.extractUsername(token);
                }
            }
            
            String originalFilename = file.getOriginalFilename();
            String correctFilename = FilenameEncodingUtils.getCorrectFilename(file);
            
            StringBuilder result = new StringBuilder();
            result.append("=== 文件名编码修复测试 ===\n");
            result.append("原始文件名: ").append(originalFilename).append("\n");
            result.append("编码修复后: ").append(correctFilename).append("\n");
            result.append("包含中文字符: ").append(FilenameEncodingUtils.containsChineseCharacters(correctFilename)).append("\n");
            result.append("是否包含乱码: ").append(containsGarbledCharacters(correctFilename)).append("\n");
            
            if (username != null) {
                // 检查重复文件名
                List<UserDocument> existingDocuments = userDocumentService.getUserDocuments(username);
                List<String> existingFilenames = existingDocuments.stream()
                        .map(UserDocument::getOriginalFilename)
                        .collect(java.util.stream.Collectors.toList());
                
                String finalFilename = FilenameEncodingUtils.handleDuplicateFilename(correctFilename, existingFilenames);
                result.append("\n=== 重复文件名处理 ===\n");
                result.append("用户现有文件: ").append(existingFilenames).append("\n");
                result.append("最终文件名: ").append(finalFilename).append("\n");
                result.append("是否重复: ").append(!finalFilename.equals(correctFilename)).append("\n");
            }
            
            return ResponseEntity.ok().body(result.toString());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("测试失败: " + e.getMessage());
        }
    }
    
    /**
     * 编码测试接口 - 测试所有可能的编码转换
     */
    @PostMapping("/test-encoding-detailed")
    public ResponseEntity<?> testEncodingDetailed(@RequestParam("file") MultipartFile file) {
        try {
            String originalFilename = file.getOriginalFilename();
            String testResult = EncodingTestUtils.testAllEncodings(originalFilename);
            
            return ResponseEntity.ok().body(testResult);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("编码测试失败: " + e.getMessage());
        }
    }
    
    /**
     * FastGPT文件名编码测试接口
     * 测试传递给FastGPT的文件名编码处理
     */
    @PostMapping("/test-fastgpt-filename")
    public ResponseEntity<?> testFastGptFilename(@RequestParam("file") MultipartFile file) {
        try {
            String originalFilename = file.getOriginalFilename();
            String correctFilename = FilenameEncodingUtils.getCorrectFilename(file);
            
            StringBuilder result = new StringBuilder();
            result.append("=== FastGPT文件名编码测试 ===\n");
            result.append("原始文件名: ").append(originalFilename).append("\n");
            result.append("后端修复后: ").append(correctFilename).append("\n");
            
            // 模拟FastGPT文件名编码处理
            String fastgptFilename = simulateFastGptEncoding(correctFilename);
            result.append("FastGPT处理后: ").append(fastgptFilename).append("\n");
            
            result.append("包含中文字符: ").append(containsChineseCharacters(fastgptFilename)).append("\n");
            result.append("包含乱码: ").append(containsGarbledCharacters(fastgptFilename)).append("\n");
            
            return ResponseEntity.ok().body(result.toString());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("FastGPT文件名测试失败: " + e.getMessage());
        }
    }
    
    /**
     * 模拟FastGPT文件名编码处理
     */
    private String simulateFastGptEncoding(String filename) {
        if (filename == null || filename.isEmpty()) {
            return "document_" + System.currentTimeMillis();
        }
        
        try {
            // 尝试UTF-8编码
            byte[] utf8Bytes = filename.getBytes(StandardCharsets.UTF_8);
            String utf8Filename = new String(utf8Bytes, StandardCharsets.UTF_8);
            
            if (containsChineseCharacters(utf8Filename) && !containsGarbledCharacters(utf8Filename)) {
                return utf8Filename;
            }
            
            // 尝试GBK编码
            try {
                byte[] gbkBytes = filename.getBytes("GBK");
                String gbkFilename = new String(gbkBytes, "GBK");
                
                if (containsChineseCharacters(gbkFilename) && !containsGarbledCharacters(gbkFilename)) {
                    return gbkFilename;
                }
            } catch (Exception e) {
                // 忽略GBK编码失败
            }
            
            // 如果都失败，返回原始文件名
            return filename;
            
        } catch (Exception e) {
            return filename;
        }
    }
    
    /**
     * 检查是否包含中文字符
     */
    private boolean containsChineseCharacters(String text) {
        if (text == null) return false;
        
        for (char c : text.toCharArray()) {
            if (c >= 0x4E00 && c <= 0x9FFF) { // 中文字符范围
                return true;
            }
        }
        return false;
    }
    
    /**
     * 检查是否包含乱码字符
     */
    private boolean containsGarbledCharacters(String text) {
        if (text == null) return true;
        
        return text.contains("?") || 
               text.contains("") || 
               text.contains("æ") || 
               text.contains("å") || 
               text.contains("è") ||
               text.contains("é") ||
               text.contains("®") ||
               text.contains("¡") ||
               text.contains("½");
    }
    
    
    /**
     * 获取文件扩展名
     */
    private String getFileExtension(String filename) {
        if (filename == null || filename.isEmpty()) {
            return "";
        }
        int lastDotIndex = filename.lastIndexOf('.');
        if (lastDotIndex > 0 && lastDotIndex < filename.length() - 1) {
            return filename.substring(lastDotIndex + 1).toLowerCase();
        }
        return "";
    }
}