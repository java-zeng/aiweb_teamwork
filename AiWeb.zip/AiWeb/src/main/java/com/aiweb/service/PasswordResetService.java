package com.aiweb.service;

public interface PasswordResetService {
}
