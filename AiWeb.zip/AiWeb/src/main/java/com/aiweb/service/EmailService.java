package com.aiweb.service;

public interface EmailService {

    public void sendEmail(String toUserEmail,String title,String veriCode);


}
