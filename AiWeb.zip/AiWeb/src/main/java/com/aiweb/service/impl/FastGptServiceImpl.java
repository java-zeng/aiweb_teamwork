package com.aiweb.service.impl;

import com.aiweb.entity.FastGptApiData;
import com.aiweb.entity.FastGptApiResponse;
import com.aiweb.service.FastGptService;
import com.aiweb.utils.FilenameEncodingUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.aiweb.mapper.UserMapper;
import com.aiweb.entity.User;


@Slf4j
@Service
public class FastGptServiceImpl implements FastGptService {
    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private ObjectMapper objectMapper;

    @Value("${fastgpt.api.baseUrl}")
    private String FastGptBaseUrl;

    @Value("${fastgpt.api.key}")
    private String fastGptApiKey;

    @Autowired
    private UserMapper userMapper;

    @Value("${fastgpt.api.dataset.create:/api/core/dataset/create}")
    private String datasetCreatePath;

    @Value("${fastgpt.api.dataset.delete:/api/core/dataset/delete}")
    private String datasetDeletePath;

    public FastGptApiResponse CreateListFromFiles(MultipartFile multipartFile, FastGptApiData fastGptApiData) throws JsonProcessingException {
        //1.构造目标URl
        String curlUrl=FastGptBaseUrl+"/api/core/dataset/collection/create/localFile";
        //2.设置http请求头
        HttpHeaders httpHeaders = new HttpHeaders();
        //指定传输的类型：file+data(文件传输模式)
        httpHeaders.setContentType(MediaType.MULTIPART_FORM_DATA);
        //添加需要的Bearer Token认证头部
        httpHeaders.setBearerAuth(fastGptApiKey);
        
        // 获取正确的文件名（解决编码问题）
        String correctFilename = FilenameEncodingUtils.getCorrectFilename(multipartFile);
        log.info("FastGPT上传 - 原始文件名: {}, 修复后文件名: {}", 
                multipartFile.getOriginalFilename(), correctFilename);
        
        // 确保传递给FastGPT的文件名编码正确
        String fastgptFilename = ensureFastGptFilenameEncoding(correctFilename);
        log.info("FastGPT最终文件名: {}", fastgptFilename);
        
        //3.构建 multipart/form-data 请求体
        LinkedMultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        //3.1添加file字段 - 使用自定义的Resource包装器确保文件名编码正确
        body.add("file", createCustomFileResource(multipartFile, fastgptFilename));
        //3.2添加data字段
        String jsonData = objectMapper.writeValueAsString(fastGptApiData);
        body.add("data",jsonData);
        //4.将header和body组成一个HttpEntity
        HttpEntity<LinkedMultiValueMap<String, Object>> httpEntity = new HttpEntity<>(body, httpHeaders);
        log.info("准备向Fastgpt发送请求");
        log.info("请求地址为:{}",curlUrl);
        log.info("请求数据部分为:{}",jsonData);
        try {
            ResponseEntity<FastGptApiResponse> response = restTemplate.exchange(curlUrl, HttpMethod.POST, httpEntity, FastGptApiResponse.class);
            //处理响应
            FastGptApiResponse responseBody = response.getBody();
            if(responseBody==null||responseBody.getCode()!=200)
            {
                log.error("FASTGPT调用失败，失败响应为:{}",responseBody);
                throw new RuntimeException("FASTGPT API调用失败");
            }
            log.info("成功上传文件到FASTGPT APi并创建了文件集合,CollectionId:{}",responseBody.getData().getCollectionId());
            return responseBody;
        }catch (HttpClientErrorException e)
        {
            log.error("调用FASTGPT API时发生HTTP客户端请求错误:{}",e.getStatusCode());
            throw new RuntimeException("请求FASTGPT APi失败，请检查参数或者APi KEY");
        }
    }

    @Override
    public String ensureUserDataset(String username) {
        User user = userMapper.selectOne(new QueryWrapper<User>().eq("username", username));
        if (user == null) {
            throw new RuntimeException("用户不存在: " + username);
        }
        
        // 如果用户已有数据集ID，直接复用（若 FastGPT 已被手动删除，将在调用上传时自动重试并重建）
        if (user.getFastgptDatasetId() != null && !user.getFastgptDatasetId().isEmpty()) {
            return user.getFastgptDatasetId();
        }
        // 调用 FastGPT 创建数据集
        String url = FastGptBaseUrl + datasetCreatePath;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(fastGptApiKey);
        // 简化：用 username 作为数据集名称
        String payload = "{\"name\":\"" + username + "\"}";
        HttpEntity<String> entity = new HttpEntity<>(payload, headers);
        try {
            ResponseEntity<String> resp = restTemplate.postForEntity(url, entity, String.class);
            String body = resp.getBody();
            if (body == null) {
                throw new RuntimeException("创建数据集失败：响应为空");
            }
            // 兼容多种返回结构
            var root = objectMapper.readTree(body);
            String datasetId = null;
            if (root.has("data")) {
                var dataNode = root.get("data");
                if (dataNode.isTextual()) {
                    datasetId = dataNode.asText();
                } else {
                    datasetId = dataNode.path("datasetId").asText(null);
                    if (datasetId == null || datasetId.isEmpty()) datasetId = dataNode.path("id").asText(null);
                    if (datasetId == null || datasetId.isEmpty()) datasetId = dataNode.path("_id").asText(null);
                }
            } else {
                // 有些实现可能直接返回 {id: "..."}
                datasetId = root.path("datasetId").asText(null);
                if (datasetId == null || datasetId.isEmpty()) datasetId = root.path("id").asText(null);
                if (datasetId == null || datasetId.isEmpty()) datasetId = root.path("_id").asText(null);
            }
            if (datasetId == null || datasetId.isEmpty()) {
                log.error("创建数据集返回原文: {}", body);
                throw new RuntimeException("创建数据集失败，未返回 datasetId");
            }
            user.setFastgptDatasetId(datasetId);
            userMapper.updateById(user);
            return datasetId;
        } catch (Exception e) {
            log.error("创建 FastGPT 数据集失败", e);
            throw new RuntimeException("创建 FastGPT 数据集失败: " + e.getMessage());
        }
    }

    /**
     * 验证数据集是否存在
     */
    private boolean validateDatasetExists(String datasetId) {
        try {
            // 尝试获取数据集信息来验证是否存在
            String url = FastGptBaseUrl + "/api/core/dataset/detail";
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(fastGptApiKey);
            
            String payload = "{\"datasetId\":\"" + datasetId + "\"}";
            HttpEntity<String> entity = new HttpEntity<>(payload, headers);
            
            ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);
            String body = response.getBody();
            
            if (body != null) {
                var root = objectMapper.readTree(body);
                // 检查响应是否表示数据集存在
                return root.path("code").asInt() == 200 || !root.path("data").isNull();
            }
            
            return false;
        } catch (Exception e) {
            log.warn("验证数据集 {} 是否存在时发生异常: {}", datasetId, e.getMessage());
            return false;
        }
    }

    @Override
    public void deleteDataset(String datasetId) {
        String url = FastGptBaseUrl + datasetDeletePath;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(fastGptApiKey);
        String payload = "{\"datasetId\":\"" + datasetId + "\"}";
        try {
            restTemplate.postForEntity(url, new HttpEntity<>(payload, headers), String.class);
        } catch (Exception e) {
            log.warn("删除 FastGPT 数据集失败: {}", e.getMessage());
        }
    }
    
    /**
     * 确保传递给FastGPT的文件名编码正确
     * 专门处理FastGPT可能存在的编码问题
     */
    private String ensureFastGptFilenameEncoding(String filename) {
        if (filename == null || filename.isEmpty()) {
            return "document_" + System.currentTimeMillis();
        }
        
        try {
            // 方法1: 尝试UTF-8编码，确保FastGPT能正确识别
            byte[] utf8Bytes = filename.getBytes(StandardCharsets.UTF_8);
            String utf8Filename = new String(utf8Bytes, StandardCharsets.UTF_8);
            
            // 检查是否包含中文字符且没有乱码
            if (containsChineseCharacters(utf8Filename) && !containsGarbledCharacters(utf8Filename)) {
                log.info("UTF-8编码文件名: {} -> {}", filename, utf8Filename);
                return utf8Filename;
            }
            
            // 方法2: 尝试GBK编码（FastGPT可能偏好GBK）
            try {
                byte[] gbkBytes = filename.getBytes("GBK");
                String gbkFilename = new String(gbkBytes, "GBK");
                
                if (containsChineseCharacters(gbkFilename) && !containsGarbledCharacters(gbkFilename)) {
                    log.info("GBK编码文件名: {} -> {}", filename, gbkFilename);
                    return gbkFilename;
                }
            } catch (Exception e) {
                log.warn("GBK编码失败: {}", e.getMessage());
            }
            
            // 方法3: 如果包含中文字符，尝试URL编码
            if (containsChineseCharacters(filename)) {
                try {
                    String urlEncoded = java.net.URLEncoder.encode(filename, StandardCharsets.UTF_8);
                    log.info("URL编码文件名: {} -> {}", filename, urlEncoded);
                    return urlEncoded;
                } catch (Exception e) {
                    log.warn("URL编码失败: {}", e.getMessage());
                }
            }
            
            // 方法4: 如果都失败，使用安全的ASCII文件名
            String safeFilename = generateSafeAsciiFilename(filename);
            log.warn("使用安全ASCII文件名: {} -> {}", filename, safeFilename);
            return safeFilename;
            
        } catch (Exception e) {
            log.error("FastGPT文件名编码处理失败: {}", e.getMessage(), e);
            return filename;
        }
    }
    
    /**
     * 检查是否包含中文字符
     */
    private boolean containsChineseCharacters(String text) {
        if (text == null) return false;
        
        for (char c : text.toCharArray()) {
            if (c >= 0x4E00 && c <= 0x9FFF) { // 中文字符范围
                return true;
            }
        }
        return false;
    }
    
    /**
     * 检查是否包含乱码字符
     */
    private boolean containsGarbledCharacters(String text) {
        if (text == null) return true;
        
        return text.contains("?") || 
               text.contains("") || 
               text.contains("æ") || 
               text.contains("å") || 
               text.contains("è") ||
               text.contains("é") ||
               text.contains("®") ||
               text.contains("¡") ||
               text.contains("½");
    }
    
    /**
     * 生成安全的ASCII文件名
     */
    private String generateSafeAsciiFilename(String originalFilename) {
        if (originalFilename == null || originalFilename.isEmpty()) {
            return "document_" + System.currentTimeMillis();
        }
        
        // 提取文件扩展名
        String extension = "";
        int lastDotIndex = originalFilename.lastIndexOf('.');
        if (lastDotIndex > 0 && lastDotIndex < originalFilename.length() - 1) {
            extension = originalFilename.substring(lastDotIndex);
        }
        
        // 生成安全的ASCII文件名
        String safeName = "document_" + System.currentTimeMillis() + extension;
        log.info("生成安全ASCII文件名: {} -> {}", originalFilename, safeName);
        return safeName;
    }
    
    /**
     * 创建自定义文件资源，确保文件名编码正确
     */
    private Resource createCustomFileResource(MultipartFile multipartFile, String correctFilename) {
        try {
            log.info("创建自定义文件资源 - 原始文件名: {}, 正确文件名: {}", 
                    multipartFile.getOriginalFilename(), correctFilename);
            
            // 创建一个自定义的InputStreamResource，使用修复后的文件名
            return new InputStreamResource(multipartFile.getInputStream()) {
                @Override
                public String getFilename() {
                    // 返回修复后的正确文件名
                    return correctFilename;
                }
                
                @Override
                public long contentLength() throws IOException {
                    return multipartFile.getSize();
                }
            };
        } catch (IOException e) {
            log.error("创建自定义文件资源失败: {}", e.getMessage(), e);
            // 如果失败，回退到原始方式
            return multipartFile.getResource();
        }
    }
}
