package com.aiweb.service;

import com.aiweb.entity.FastGptApiData;
import com.aiweb.entity.FastGptApiResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.web.multipart.MultipartFile;

public interface FastGptService {
    public FastGptApiResponse CreateListFromFiles(MultipartFile multipartFile, FastGptApiData fastGptApiData) throws JsonProcessingException;

    /**
     * 确保为指定用户名存在一个数据集，不存在则在 FastGPT 端创建并返回 datasetId。
     */
    String ensureUserDataset(String username);

    /**
     * 删除指定数据集（用于用户注销时清理）。
     */
    void deleteDataset(String datasetId);
}
