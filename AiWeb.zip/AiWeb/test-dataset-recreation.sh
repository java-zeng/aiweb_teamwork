#!/bin/bash

# 数据集重新创建测试脚本
# 测试删除知识库后重新上传文件的逻辑

echo "=== 数据集重新创建测试脚本 ==="
echo ""

# 设置变量
BASE_URL="http://localhost:8890"
TOKEN="eyJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6InpqIiwiZXhwIjoxNzYwNDU2NDc1fQ.7SHgtYQVM75ARpADfSXbDUcOSvfiOSxAg20k3WGMyIk"

echo "1. 测试文件名编码修复..."
echo "上传文件: 培养计划-S250132007-曾静.pdf"
echo ""

curl -X POST "$BASE_URL/api/v1/collections/test-filename-encoding" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@培养计划-S250132007-曾静.pdf" \
  -w "\n\nHTTP状态码: %{http_code}\n" \
  -s

echo ""
echo "2. 测试自动上传功能（应该自动创建新的数据集）..."
echo ""

curl -X POST "$BASE_URL/api/v1/collections/auto-upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@培养计划-S250132007-曾静.pdf" \
  -w "\n\nHTTP状态码: %{http_code}\n" \
  -s

echo ""
echo "3. 查看用户文件列表..."
echo "检查是否成功创建新的数据集和文件..."
echo ""

curl -X GET "$BASE_URL/api/v1/collections/documents" \
  -H "Authorization: Bearer $TOKEN" \
  -w "\n\nHTTP状态码: %{http_code}\n" \
  -s

echo ""
echo "=== 测试完成 ==="
echo "如果看到正确的文件名和成功上传，说明数据集重新创建功能正常！"
