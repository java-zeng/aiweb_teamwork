#!/bin/bash

# 文件名编码测试脚本
# 用于测试文件名编码修复和重复处理功能

echo "=== 文件名编码测试脚本 ==="
echo ""

# 设置变量
BASE_URL="http://localhost:8890"
TOKEN="eyJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6InpqIiwiZXhwIjoxNzYwNDU2NDc1fQ.7SHgtYQVM75ARpADfSXbDUcOSvfiOSxAg20k3WGMyIk"

echo "1. 测试文件名编码修复..."
echo "上传文件: 培养计划-S250132007-曾静.pdf"
echo ""

curl -X POST "$BASE_URL/api/v1/collections/test-filename-encoding" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@培养计划-S250132007-曾静.pdf" \
  -w "\n\nHTTP状态码: %{http_code}\n" \
  -s

echo ""
echo "1.1 详细编码测试..."
echo ""

curl -X POST "$BASE_URL/api/v1/collections/test-encoding-detailed" \
  -F "file=@培养计划-S250132007-曾静.pdf" \
  -w "\n\nHTTP状态码: %{http_code}\n" \
  -s

echo ""
echo "2. 测试重复文件名处理..."
echo "再次上传相同文件名的文件..."
echo ""

curl -X POST "$BASE_URL/api/v1/collections/test-filename-encoding" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@培养计划-S250132007-曾静.pdf" \
  -w "\n\nHTTP状态码: %{http_code}\n" \
  -s

echo ""
echo "3. 测试正式上传功能..."
echo "使用自动上传接口..."
echo ""

curl -X POST "$BASE_URL/api/v1/collections/auto-upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@培养计划-S250132007-曾静.pdf" \
  -w "\n\nHTTP状态码: %{http_code}\n" \
  -s

echo ""
echo "4. 查看用户文件列表..."
echo ""

curl -X GET "$BASE_URL/api/v1/collections/documents" \
  -H "Authorization: Bearer $TOKEN" \
  -w "\n\nHTTP状态码: %{http_code}\n" \
  -s

echo ""
echo "=== 测试完成 ==="
