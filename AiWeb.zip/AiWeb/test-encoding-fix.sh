#!/bin/bash

# 编码修复测试脚本
# 测试基于测试结果优化的编码修复算法

echo "=== 编码修复测试脚本 ==="
echo ""

# 设置变量
BASE_URL="http://localhost:8890"
TOKEN="eyJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6InpqIiwiZXhwIjoxNzYwNDU2NDc1fQ.7SHgtYQVM75ARpADfSXbDUcOSvfiOSxAg20k3WGMyIk"

echo "1. 测试优化后的编码修复算法..."
echo "上传文件: 培养计划-S250132007-曾静.pdf"
echo ""

curl -X POST "$BASE_URL/api/v1/collections/test-filename-encoding" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@培养计划-S250132007-曾静.pdf" \
  -w "\n\nHTTP状态码: %{http_code}\n" \
  -s

echo ""
echo "2. 测试正式上传功能..."
echo "使用优化后的自动上传接口..."
echo ""

curl -X POST "$BASE_URL/api/v1/collections/auto-upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@培养计划-S250132007-曾静.pdf" \
  -w "\n\nHTTP状态码: %{http_code}\n" \
  -s

echo ""
echo "3. 查看用户文件列表..."
echo "检查文件名是否正确显示..."
echo ""

curl -X GET "$BASE_URL/api/v1/collections/documents" \
  -H "Authorization: Bearer $TOKEN" \
  -w "\n\nHTTP状态码: %{http_code}\n" \
  -s

echo ""
echo "=== 测试完成 ==="
echo "如果看到正确的文件名 '培养计划-S250132007-曾静.pdf'，说明编码修复成功！"
